// banco de dados - aula 26

create table if not exists turma (
    turma_id serial primary key,
    turma_nome varchar(100) not null,
    turma_serie smallint not null,
    turma_divisao boolean
);

create table if not exists funcao (
    funcao_id serial primary key,
    funcao_nome varchar(100) not null
);

create table if not exists usuario (
    usuario_id serial primary key,
    usuario_nome varchar(100) not null,
    usuario_turma int references turma(turma_id) not null,
    usuario_funcao int references funcao(funcao_id) not null,
    usuario_email varchar(150) unique not null,
    usuario_senha varchar(25) not null,
    usuario_telefone int unique not null,
    usuario_grupo char(3) not null default "A"
);